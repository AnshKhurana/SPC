from django.apps import AppConfig


class FiledatabaseConfig(AppConfig):
    name = 'filedatabase'
